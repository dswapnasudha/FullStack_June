
package steps;

import api.AccountAPI;
import pojos.BaseResponse;
import context.ResponseContext;
import pojos.CreateAccountRequest;
import pojos.CreateResponse;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import com.github.javafaker.Faker;
import org.testng.Assert;

public class AccountSteps {
    private AccountAPI accountAPI;
    private CreateAccountRequest accountRequest;
    private final ResponseContext context;
    private CreateResponse createResponse;
    private Faker faker = new Faker();

    public AccountSteps(ResponseContext context) {
        accountAPI = new AccountAPI();
        this.context = context;
    }

    @Given("I have valid account details")
    public void iHaveValidAccountDetails() {
        accountRequest = new CreateAccountRequest();
        accountRequest.setName(faker.company().name());
        accountRequest.setPhone(faker.phoneNumber().phoneNumber());
        accountRequest.setWebsite(faker.internet().url());
        accountRequest.setIndustry(faker.company().industry());
    }

    @When("I create a new account")
    public void iCreateANewAccount() {
        createResponse = accountAPI.createAccount(accountRequest);
        Assert.assertNotNull(createResponse.getId(), "Account id should not be null");
        context.setBaseResponse(createResponse);
    }

    @Given("I have an existing account as {string}")
    public void iHaveExistingAccount(String accountId) {
        context.setId(accountId);
    }

    @When("I delete the account")
    public void iDeleteTheAccount() {
        BaseResponse deleteResponse = accountAPI.deleteAccount(context.getId());
        context.setBaseResponse(deleteResponse);
    }
}
