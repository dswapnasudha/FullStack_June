
package api;

import io.restassured.response.Response;
import pojos.CreateAccountRequest;
import pojos.CreateResponse;
import pojos.BaseResponse;

public class AccountAPI extends BaseAPI {
    private static final String ACCOUNT_ENDPOINT = "/Account";
    
    public CreateResponse createAccount(CreateAccountRequest request) {
        String endpoint = baseUrl + ACCOUNT_ENDPOINT;
        Response response = post(endpoint, request, getAuthHeaders());
        try {
            CreateResponse createResponse = mapper.readValue(response.asString(), CreateResponse.class);
            createResponse.setStatusCode(response.getStatusCode());
            return createResponse;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse Create Account response", e);
        }
    }

    public BaseResponse deleteAccount(String accountId) {
        String endpoint = baseUrl + ACCOUNT_ENDPOINT + "/" + accountId;
        Response response = delete(endpoint, getAuthHeaders());
        try {
            BaseResponse deleteResponse = new BaseResponse();
            deleteResponse.setStatusCode(response.getStatusCode());
            return deleteResponse;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse Delete Account response", e);
        }
    }
}
