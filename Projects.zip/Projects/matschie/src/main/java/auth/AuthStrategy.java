package auth;

public interface AuthStrategy {
    String getToken();
}
