package com.testleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerRaWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwaggerRaWebApplication.class, args);
    }
}
